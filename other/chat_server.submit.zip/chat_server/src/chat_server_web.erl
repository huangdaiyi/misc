

-module(chat_server_web).
-author('Hardy.D.Huang@newegg.com').
-export([start/1, stop/0, loop/2]).

%10s 不活动，则认为用户已经离开页面
-define(TIMEOUT, 10000).
-define(CHATROOM, chatroom).

%% External API
% Options Vaules: [{ip,{0,0,0,0}},{port,8080},{docroot,"d:/erlang/chat_server/priv/www"}]
start(Options) ->
    io:format("start Options ~p~n",[Options]),
   
    {DocRoot, Options1} = get_option(docroot, Options),
    Loop = fun (Req) ->
                   ?MODULE:loop(Req, DocRoot)
           end,
    NewPid = spawn(fun() ->
                room([])
            end),
    register(?CHATROOM, NewPid),
    io:format("registering  proccess ~p~n",[NewPid]),
    mochiweb_http:start([{name, ?MODULE}, {loop, Loop} | Options1]).

stop() ->
    mochiweb_http:stop(?MODULE).

room(Users) ->
    receive
        {From, add} ->
            From ! added,
            io:format("~p~n",[[From | Users]]) ,
            room([From | Users]);
        {From, delete} ->
            From ! deleted,
            io:format("~p~n",[Users -- [From]]) ,
            room(Users -- [From]);
        {From, send, Message} ->
            From ! sended,
            lists:foreach(fun(User) ->
                                  User ! Message
                          end, Users),
            room([]);
        _Any ->
            room(Users)
    end.

loop(Req, DocRoot) ->
    "/" ++ Path = Req:get(path),
    case Req:get(method) of
        Method when Method =:= 'GET'; Method =:= 'HEAD' ->
            case Path of
                "chat" ->
                    %register room
                    %add a user to room 
                    ?CHATROOM ! {self(), add},
                    receive
                        added ->
                            receive
                                Message ->
                                    {Type, Message} = {ok, Message}
                            after ?TIMEOUT ->
                                 {Type, Message} = {timeout, <<"no message">>}
                            end
                    after 1000 ->
                        {Type, Message} = {timeout, <<"timeout">>}
                    end,

                    case Type of
                        timeout ->
                            ?CHATROOM ! {self(), delete},
                            receive
                                deleted ->
                                    ok
                            after 1000 ->
                                ok
                            end;
                        ok ->
                            ok
                    end,

                    Req:ok({"application/json", mochijson2:encode({
                            struct, [
                                 {"type" ,Type}, {"message", Message}
                            ]
                        })
                    });

                 _ ->
                    Req:serve_file(Path, DocRoot)
            end;
        'POST' ->
            case Path of
                "chat" ->
                    Data = Req:parse_post(),
                    % print send message
                    % io:format("message from post:~p~n",[proplists:get_value("message", Data)]),
                    ?CHATROOM ! {self(), send, list_to_binary(proplists:get_value("message", Data))},
                    receive
                        sended ->
                            Body = {ok, <<"send success">>}
                    after 1000 ->
                        Body = {timeout, <<"timeout">>}
                    end,

                    Req:ok({"text/javascript", mochijson2:encode({
                            struct, [
                                Body
                            ]
                        })
                    });
                _ ->
                    Req:not_found()
            end;
        _ ->
            Req:respond({501, [], []})
    end.

%% Internal API

get_option(Option, Options) ->
    {proplists:get_value(Option, Options), proplists:delete(Option, Options)}.